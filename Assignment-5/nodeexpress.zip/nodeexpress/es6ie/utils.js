// export default function add(a, b){
export function add(a, b){
    return a+b
}

export function sub(a, b){
    return a-b
}

export const PI = 3.14


// default export
// export default add


// named export
// export {add, sub, PI}