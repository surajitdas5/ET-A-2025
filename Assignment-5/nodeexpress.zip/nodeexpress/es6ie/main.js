// import add from './utils.js'
// import sum from './utils.js'

// console.log(add(1, 2));


// import { add, sub, PI } from "./utils.js"
import { add as sum, sub, PI } from "./utils.js"
// console.log(add(9, 8));
console.log(sum(9, 8));
console.log(sub(9, 8));
console.log(PI);
