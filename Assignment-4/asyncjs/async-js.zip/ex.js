let std = {
    name: "sam", // name
    "roll": 123
}