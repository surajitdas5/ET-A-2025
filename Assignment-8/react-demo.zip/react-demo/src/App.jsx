import "bootstrap/dist/css/bootstrap.min.css"
import "bootstrap/dist/js/bootstrap.bundle.min.js"
import First from "./pages/First";
import "./App.css"
import Second from "./pages/Second";

function App(){

return (
    <>
      {/* {First()} */}
        {/* <First></First> */}
        {/* <First /> */}
        <Second />
        <Second />
        <Second />
        <Second />
    </>
  )
}

export default App;