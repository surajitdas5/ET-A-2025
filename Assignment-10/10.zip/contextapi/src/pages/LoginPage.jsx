import React from 'react'
import LoginCard from '../components/LoginCard'

// const LoginPage = ({ isSignedIn, toogleSignIn }) => {
//   return (
//     <div>
//         <LoginCard isSignedIn={isSignedIn} toogleSignIn={toogleSignIn} />
//     </div>
//   )
// }

const LoginPage = () => {
    return (
      <div>
          <LoginCard />
      </div>
    )
  }

export default LoginPage