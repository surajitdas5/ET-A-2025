import React from 'react'
import LoginForm from './LoginForm'

// const LoginCard = ({ isSignedIn, toogleSignIn }) => {
//   return (
//     <div>
//         <LoginForm isSignedIn={isSignedIn} toogleSignIn={toogleSignIn} />
//     </div>
//   )
// }

const LoginCard = () => {
    return (
      <div>
          <LoginForm />
      </div>
    )
  }

export default LoginCard